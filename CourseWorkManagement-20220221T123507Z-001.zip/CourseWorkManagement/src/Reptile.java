 public interface Reptile{
    void move();

    private void stop(){
        System.out.println("I am stopping");
    }
}

