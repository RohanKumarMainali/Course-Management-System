public interface Camera {
    void turn();
}
 interface GPS{
    void turningGPS();
}
class Smartphone implements Camera,GPS{
    public void turn(){
        System.out.println("Turning on camera");
    }
    public void turningGPS(){
        System.out.println("Turning on GPS");

    }

    public static void main(String[] args) {
        Smartphone obj=new Smartphone();
        obj.turn();
        GPS obj1=new Smartphone();
        obj1.turningGPS();
    }
}
