package com.CourseWork;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class RemoveTutor extends JFrame implements ActionListener {
    private JPanel panel;
    private JLabel tutorId;
    private JTextField tutorIdText;
    private JButton remove;

    RemoveTutor(){

        setBounds(500,250,500,200);
        panel=new JPanel();
        panel.setLayout(null);

        tutorId=new JLabel("Tutor ID: ");
        tutorId.setFont(new Font("Verdana", Font.PLAIN, 18));
        tutorId.setBounds(80,40,100,40);
        panel.add(tutorId);

        tutorIdText=new JTextField();
        tutorIdText.setBounds(240,40,170,40);
        panel.add(tutorIdText);

        remove=new JButton("Remove");
        remove.setBounds(180,100,100,30);
        remove.addActionListener(this);
        panel.add(remove);

        setContentPane(panel);
        setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            Conn connection=new Conn();
            if(e.getSource()==remove){
                String sql="select * from teacher;";
                Statement st=connection.c.createStatement();
                ResultSet rs=st.executeQuery(sql);
                boolean decide=true;
                while(rs.next()){
                    if(rs.getString("id").equals(tutorIdText.getText())){
                        decide=false;
                    }
                }
                if(decide==false){
                    String sql1="delete from teacher where id=?;";
                    PreparedStatement ps= connection.c.prepareStatement(sql1);
                    ps.setString(1,tutorIdText.getText());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Teacher removed");
                }
                else{
                    JOptionPane.showMessageDialog(null,"Tutor Id didn't matched");
                }
            }
        }catch(Exception ae){
            System.out.println(ae);
        }


    }

    public static void main(String[] args) {

        new RemoveTutor();
    }
}
