package com.CourseWork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ShowTutor extends JFrame implements ActionListener{
    private JPanel panel;
    private JTable table;
    private JButton add,remove;

    private String []columnName={"Tutor Name","ID","Age","Gender","Phone No.","Address","Module Name","Semester"};
    private ArrayList<String> tutorName=new ArrayList<>();
    private ArrayList<String> tutorId=new ArrayList<>();
    private ArrayList<String> age=new ArrayList<>();
    private ArrayList<String> gender=new ArrayList<>();
    private ArrayList<String> phoneNumber=new ArrayList<>();
    private ArrayList<String> address=new ArrayList<>();
    private ArrayList<String> moduleId=new ArrayList<>();
    private ArrayList<String> moduleName=new ArrayList<>();
    private ArrayList<String> semester=new ArrayList<>();
    private ArrayList<Object> Total=new ArrayList<>();

    public JPanel ShowTutor(){
        panel=new JPanel();

        setBounds(500,200,600,500);
        setLayout(null);

        int count=0;
        try{
            Conn connection = new Conn();



            String sql2="select * from teacher order by id;";
            Statement st1=connection.c.createStatement();
            ResultSet rs1=st1.executeQuery(sql2);

            while(rs1.next()){
                tutorName.add(rs1.getString("name"));
                tutorId.add(rs1.getString("id"));
                age.add(rs1.getString("age"));
                gender.add(rs1.getString("gender"));
                phoneNumber.add(rs1.getString("phoneNumber"));
                address.add(rs1.getString("address"));
                if(rs1.getString("moduleId")==null){
                    moduleName.add("Not assigned");
                    semester.add("Not assigned");

                }
                else{
                    String sql1="select * from modules order by semester;";
                    Statement st=connection.c.createStatement();
                    ResultSet rs= st.executeQuery(sql1);
                    while(rs.next()){
                        System.out.println("check");
                        if(rs.getString("moduleId").equals(rs1.getString("moduleId"))){
                            System.out.println("matched");
                            moduleName.add(rs.getString("moduleName"));
                            semester.add(rs.getString("semester"));
                        }
                    }
                }
                count++;


            }
            String[][] data=new String[count][8];
            for(int i=0;i<count;i++){
                for(int j=0;j<8;j++){
                    data[i][j]= tutorName.get(i);
                    j++;
                    data[i][j]=tutorId.get(i);
                    j++;
                    data[i][j]=age.get(i);
                    j++;
                    data[i][j]=gender.get(i);
                    j++;
                    data[i][j]=phoneNumber.get(i);
                    j++;
                    data[i][j]=address.get(i);
                    j++;
                    data[i][j]=moduleName.get(i);
                    j++;
                    data[i][j]=semester.get(i);

                }
                DefaultTableModel model=new DefaultTableModel(data,columnName);
                table = new JTable(model);


                table.getColumnModel().getColumn(0).setPreferredWidth(150);
                table.getColumnModel().getColumn(1).setPreferredWidth(80);
                table.getColumnModel().getColumn(2).setPreferredWidth(80);
                table.getColumnModel().getColumn(3).setPreferredWidth(100);
                table.getColumnModel().getColumn(4).setPreferredWidth(100);
                table.getColumnModel().getColumn(5).setPreferredWidth(200);
                table.getColumnModel().getColumn(6).setPreferredWidth(200);
                table.getColumnModel().getColumn(7).setPreferredWidth(150);
            }
            add=new JButton("Add Tutor");
            remove=new JButton("Remove Tutor");
            add.addActionListener(this);
            JScrollPane pane = new JScrollPane(table);
//            pane.setMinimumSize(new Dimension(1000, 23));
            pane.setPreferredSize(new Dimension(1000,500));
            table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            panel.setLayout(null);
            add.setBounds(1080,100,120,20);
            remove.setBounds(1080,130,120,20);

            pane.setBounds(250,20,800,500);
            panel.add(add);
            remove.addActionListener(this);
            panel.add(remove);
            panel.add(pane);
//            panel.add(add);
//            panel.add(remove);
            panel.setBackground(new Color(0100,50,5));


//            st.setString(1,course_id); //passing arguments
//            ResultSet rs=st.executeQuery();
//            while(rs.next()){
//                ModuleName.add(rs.getString("moduleName"));
//                ModuleId.add(rs.getString("moduleId"));
//                Semester.add(rs.getString("semester"));
//                count++;
//
//
//            }
//
//
//            panel.add(new JScrollPane(table));
//            setContentPane(panel);
////            setVisible(true);
        }catch (Exception ae){
            System.out.println(ae);
        }
        return panel;


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            Conn connection = new Conn();
        if(e.getSource()==add){
            AddTutor obj=new AddTutor();
            obj.addTutorFrame();
        }
        if(e.getSource()==remove){
            new RemoveTutor();
        }
        }catch (Exception ae){
            System.out.println(ae);
        }
    }
}
