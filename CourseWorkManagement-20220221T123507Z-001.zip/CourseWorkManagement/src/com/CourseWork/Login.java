package com.CourseWork;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Login extends JFrame implements ActionListener {
    private JPanel panel;
    private JTextField textField;
    private JPasswordField passwordField;
    private JButton btn1, btn2, btn3;
    private String[] userList = {"admin", "student", "teacher"};
    private JComboBox user;
    private JButton[] adminNav = {new JButton("Home"), new JButton("Course"), new JButton("Teacher"), new JButton("Result"), new JButton("Student"), new JButton("Logout")};
//    private JButton[] teacherNav={new JButton("Home"),new JButton("Mark"),new JButton("Logout")};
//    private ArrayList<String> adminNav=new ArrayList<>();


    Login() {
        setTitle("Course Management System");
        setLayout(null);
        setBounds(400, 200, 500, 500);
        ImageIcon image = new ImageIcon("C:/Users/user/Desktop/logo.png");
        setIconImage(image.getImage());

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setBackground(new Color(25, 59, 100));
        setContentPane(panel); // The visible part of frame is actually Content Pane
        panel.setLayout(null);

        JLabel l1 = new JLabel("Username: ");
        l1.setBounds(120, 45, 120, 26);
        l1.setForeground(new Color(250, 225, 220));
        panel.add(l1);

        JLabel l2 = new JLabel("Password: ");
        l2.setBounds(120, 100, 120, 26);
        l2.setForeground(new Color(250, 225, 220));
        panel.add(l2);

        textField = new JTextField();
        textField.setBounds(240, 45, 120, 20);
        panel.add(textField);

        passwordField = new JPasswordField();
        passwordField.setBounds(240, 100, 120, 20);
        panel.add(passwordField);
        setVisible(true);


        btn1 = new JButton("Login");
        btn1.setBackground(new Color(255, 220, 205));
        btn1.setForeground(new Color(10, 60, 70));
        btn1.setBounds(150, 200, 120, 26);
        panel.add(btn1);
        btn1.addActionListener(this);

        user = new JComboBox(userList);
        user.setBounds(150, 150, 120, 26);

        panel.add(user);
        setContentPane(panel);
        setVisible(true);
        btn2 = new JButton("SignUp");

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(btn1)) {
            Boolean status = false;
            try {
                Conn connection = new Conn();
                if (userList[user.getSelectedIndex()].equals("admin")) {
                    String sql = "select * from account where username=? and password=?";  //checking the entered arguments in database table
                    PreparedStatement st = connection.c.prepareStatement(sql);
                    st.setString(1, textField.getText()); //passing arguments
                    st.setString(2, passwordField.getText());
                    ResultSet rs = st.executeQuery();  //Resultset class checks the each row of mysql table from first to last
                    if (rs.next()) {
                        AdminHome obj = new AdminHome();
                        obj.setHeader("Admin Dashboard");
                        obj.setNavBar(adminNav);
                        obj.adminHomeFrame();
                        setVisible(false);
                        System.out.println("Logged in");
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid username or password");
                    }

                } else if (userList[user.getSelectedIndex()].equals("student")) {
                    boolean decide = true;
                    String password = "student";
                    String sql = "select * from student_details;";
                    Statement st = connection.c.createStatement();
                    ResultSet rs = st.executeQuery(sql);
                    while (rs.next()) {
                        if (textField.getText().equals(rs.getString("student_id")) && passwordField.getText().equals(password)) {
                            setVisible(false);
                            StudentHome obj1 = new StudentHome();
                            obj1.setHeader("Student Dashboard");
                            obj1.studentHomeFrame(rs.getString("student_id"));
                            System.out.println("hello " + rs.getString("student_name"));
                            decide = false;

                        }
                    }
                    if (decide == true) {
                        JOptionPane.showMessageDialog(null, "Incorrect username or password");
                    }

                } else if (userList[user.getSelectedIndex()].equals("teacher")) {
                    boolean decide = true;
                    String password = "teacher";
                    String sql = "select * from teacher;";
                    Statement st = connection.c.createStatement();
                    ResultSet rs = st.executeQuery(sql);
                    while (rs.next()) {
                        if (textField.getText().equals(rs.getString("id")) && passwordField.getText().equals(password)) {
                            setVisible(false);
                           TutorHome obj= new TutorHome();
                           obj.tutorHomeFrame(rs.getString("id"));
                            System.out.println("hello " + rs.getString("name"));
                            decide = false;
                        }
                    }
                    if (decide == true) {
                        JOptionPane.showMessageDialog(null, "Incorrect username or password");
                    }
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                System.out.println(ex);
            }

        }
    }

    public static void main(String[] args) {
        Login obj = new Login();
    }
}
