package com.CourseWork;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class AddModule extends JFrame implements ActionListener {
    public JButton add;
    private String text;
    public JLabel courseName,sem,moduleName,moduleId,courseId;
    public JTextField courseNameText,semText,moduleNameText,moduleIdText,courseIdText;
    private JPanel mainPanel;
    private JRadioButton compulsory,optional;
    private ButtonGroup btnGroup;



     void addModuleFrame(){
         setLayout(null);
        setBounds(400,150,600,480);
        mainPanel=new JPanel();
         mainPanel.setLayout(null);

         courseName=new JLabel("Course Name: ");
         courseName.setFont(new Font("Verdana", Font.PLAIN, 18));
        courseName.setBounds(40,40,200,40);
        mainPanel.add(courseName);

         courseId=new JLabel("Course Id: ");
         courseId.setFont(new Font("Verdana", Font.PLAIN, 18));
         courseId.setBounds(40,80,200,40);
         mainPanel.add(courseId);



        sem=new JLabel("Semester: ");
         sem.setFont(new Font("Verdana", Font.PLAIN, 18));
         sem.setBounds(40,120,200,40);
         mainPanel.add(sem);

         moduleName = new JLabel("Module Name: ");
         moduleName.setFont(new Font("Verdana",Font.PLAIN,18));
         moduleName.setBounds(40,160,200,40);
         mainPanel.add(moduleName);

         moduleId=new JLabel("Module Id: ");
         moduleId.setFont(new Font("Verdana",Font.PLAIN,18));
         moduleId.setBounds(40,200,200,40);
         mainPanel.add(moduleId);

         courseNameText=new JTextField();
         courseNameText.setBounds(250,40,300,35);
         mainPanel.add(courseNameText);

         courseIdText=new JTextField();
         courseIdText.setBounds(250,80,300,35);
         mainPanel.add(courseIdText);



         semText=new JTextField();
         semText.setBounds(250,120,300,35);
         mainPanel.add(semText);

         moduleNameText=new JTextField();
         moduleNameText.setBounds(250,160,300,35);
         mainPanel.add(moduleNameText);



         moduleIdText=new JTextField();
         moduleIdText.setBounds(250,200,300,35);
         mainPanel.add(moduleIdText);

         compulsory=new JRadioButton("Compulsory");
         compulsory.setBounds(170,250,120,35);
         compulsory.setActionCommand("Compulsory");

         optional=new JRadioButton("Optional");
         optional.setBounds(340,250,150,35);
         optional.setActionCommand("Optional");


          btnGroup = new ButtonGroup();
         btnGroup.add(compulsory);
         btnGroup.add(optional);

         compulsory.addActionListener(this);
         optional.addActionListener(this);
         mainPanel.add(compulsory);
         mainPanel.add(optional);


         add=getAddBtn();
         add.setBounds(225,300,120,35);
         mainPanel.add(add);


        setContentPane(mainPanel);
        setVisible(true);
        add.addActionListener(this);

    }
    public void setAddBtn(JButton addBtn){

         this.add=addBtn;
    }
    public JButton getAddBtn(){
        return this.add;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try{
            Conn connection = new Conn();
         if(e.getSource()==add){
             if(courseNameText.getText().equals("")){
                 JOptionPane.showMessageDialog(null,"Please Enter Course Name");
             }
             else{
                 String sql1="select * from courses";
                 String sql2="select * from modules";
                 Statement st=connection.c.createStatement();
                 ResultSet rs=st.executeQuery(sql1);
                 Statement st1=connection.c.createStatement();
                 ResultSet rs1=st1.executeQuery(sql2);
                 boolean decide=true;

                 while(rs.next()) {
                     if (rs.getString("courseName").equals(courseNameText.getText()) && (rs.getString("course_id").equals(courseIdText.getText()))) {
                         decide = false;
                     }


                 }
                 while(rs1.next()){
                     if(rs1.getString("moduleId").equals(moduleIdText.getText())){
                         JOptionPane.showMessageDialog(null,"Duplicate Module Id not allowed");
                     }
                 }
                 if(decide==true){
                     JOptionPane.showMessageDialog(null,"Incorrect Course Name or Course Id");
                 }
                 else{
                     String sql="insert into modules (moduleName,moduleId,semester,course_id,Choice) values (?,?,?,?,?);";
                     PreparedStatement ps=connection.c.prepareStatement(sql);
                     ps.setString(1,moduleNameText.getText());
                     ps.setString(2,moduleIdText.getText());
                     ps.setString(3,semText.getText());
                     ps.setString(4,courseIdText.getText());
                     ps.setString(5, String.valueOf(btnGroup.getSelection().getActionCommand()));
                     ps.executeUpdate();
                     JOptionPane.showMessageDialog(null,"Module added successfully");
                 }
             }

         }
        }catch (Exception ae){
            System.out.println(ae);
        }

    }

    public static void main(String[] args) {
       AddModule obj= new AddModule();
        obj.setAddBtn(new JButton("Add"));
        obj.addModuleFrame();


    }
}
