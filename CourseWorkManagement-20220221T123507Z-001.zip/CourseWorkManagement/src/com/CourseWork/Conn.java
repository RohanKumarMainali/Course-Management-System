package com.CourseWork;
import java.sql.*;

public class Conn {
    Connection c;
    Statement s;
    Conn(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            c=DriverManager.getConnection("jdbc:mysql:///admin","root","");
            s= c.createStatement();
        }
        catch (Exception e){
            System.out.println(e);
        }

    }

    public static void main(String[] args) {
        Conn obj=new Conn();
    }

}
