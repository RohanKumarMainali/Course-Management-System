package com.CourseWork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ShowModules extends JFrame  {
    private JPanel panel;
    private JTable table;

    private String []columnName={"ModuleName","ModuleId","Semester"};
    private ArrayList<String> ModuleName=new ArrayList<>();
    private ArrayList<String> ModuleId=new ArrayList<>();
    private ArrayList<String> Semester=new ArrayList<>();
    private ArrayList<Object> Total=new ArrayList<>();

    public JPanel ShowModules(String course_id){
        panel=new JPanel();

        setBounds(500,200,600,500);
        setLayout(null);

        int count=0;
        try{
            Conn connection = new Conn();

            String sql1="select * from modules where course_id =? order by semester";
            PreparedStatement st=connection.c.prepareStatement(sql1);

            st.setString(1,course_id); //passing arguments
            ResultSet rs=st.executeQuery();
            while(rs.next()){
                ModuleName.add(rs.getString("moduleName"));
                ModuleId.add(rs.getString("moduleId"));
                Semester.add(rs.getString("semester"));
                count++;


            }
            String[][] data=new String[count][3];
            for(int i=0;i<count;i++){
                for(int j=0;j<3;j++){
                    data[i][j]= ModuleName.get(i);
                    j++;
                    data[i][j]=ModuleId.get(i);
                    j++;
                    data[i][j]=Semester.get(i);

                }
                DefaultTableModel model=new DefaultTableModel(data,columnName);
                table = new JTable(model);

            }

            panel.add(new JScrollPane(table));
            setContentPane(panel);
//            setVisible(true);
        }catch (Exception ae){
            System.out.println(ae);
        }
        return panel;


    }


    public static void main(String[] args) {
//        new ShowModules("1");
    }
}
