package com.CourseWork;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;

public class RemoveCourse extends AddCourse {
public JButton b1;

    void remove(){
        RemoveCourse obj=new RemoveCourse();
        obj.setAddBtn(new JButton("Remove"));
        obj.addCourseFrame();
//        b1=new JButton("hello");
//        b1.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent a) {
        try {
//            RemoveCourse obj=new RemoveCourse();
            Conn connection =new Conn();
            if(a.getSource()==(addBtn)){
                String sql="delete from courses where courseName=?";
                String name=t1.getText();
                PreparedStatement ps=connection.c.prepareStatement(sql);
                ps.setString(1,name);
                ps.executeUpdate();
                t1.setText("");
                System.out.println("removing");
            }
        }catch (Exception ae){
            System.out.println(ae);
        }


    }

    public static void main(String[] args) {
        RemoveCourse obj1=new RemoveCourse();
        obj1.remove();

    }



}
