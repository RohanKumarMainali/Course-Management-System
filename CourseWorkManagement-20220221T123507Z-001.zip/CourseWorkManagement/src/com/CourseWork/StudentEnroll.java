package com.CourseWork;

import javax.swing.*;
import javax.swing.plaf.nimbus.State;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class StudentEnroll extends JFrame implements ActionListener {
    private JPanel panel,optionalPanel;
    private JLabel courses,semester;
    private ArrayList <String> courseChoiceList=new ArrayList<>();
    private ArrayList<String> semesterChoiceList=new ArrayList<>();
    private JComboBox courseChoice,semesterChoice;
    private  JCheckBox moduleChoice;
    private String courseName;
    private JButton enroll;
    private String sem,courseId,studentId;
    private ButtonGroup btnGrp1=new ButtonGroup();
    private ArrayList<String> compulsoryModules=new ArrayList<>();
    private ArrayList<JRadioButton> optionalModules=new ArrayList<>();
    private boolean decide=false;
    private int count=0;

    JLabel message;
    private String value,optionalChoice;
    public void setValue(String value){
        this.value=value;
    }
    public String getValue(){
        return value;
    }

    public void setSem(String sem){
        this.sem=sem;
    }
    public String getSem(){
        return sem;
    }
    public void setChoice(String optionalChoice){
        this.optionalChoice=optionalChoice;
    }
    String getChoice(){
        return optionalChoice;
    }
    public void studentEnrollFrame(String student_id1){
        StudentEnroll obj=new StudentEnroll();
        setValue(student_id1);
        System.out.println(student_id1);
        panel=new JPanel();
        panel.setBackground(new Color(19,20,255));
        optionalPanel=new JPanel();
        optionalPanel.setLayout(null);

        setBounds(500,200,600,500);
//        setLayout(null);
        panel.setLayout(null);
        courses=new JLabel("Course");
        courses.setBounds(50,80,80,40);
        courses.setFont(new Font("Verdana",Font.PLAIN,18));
        courses.setForeground(Color.WHITE);
        panel.add(courses);

        semester=new JLabel("Semester");
        semester.setBounds(230,80,120,40);
        semester.setFont(new Font("Verdana",Font.PLAIN,18));
        semester.setForeground(Color.WHITE);


        enroll=new JButton("Enroll");
        enroll.setBounds(230,270,120,40);
        enroll.setFont(new Font("Verdana",Font.PLAIN,18));
        panel.add(enroll);
        panel.add(semester);
        setVisible(true);

        try{
            Conn connection=new Conn();
            String sql="select * from courses";
            Statement st= connection.c.createStatement();
            ResultSet rs= st.executeQuery(sql);
            int semesterCount=0;
            while(rs.next()){
                System.out.println(rs.getString("courseName"));
                courseChoiceList.add(rs.getString("courseName"));

            }
            String[] courseChoiceArray=new String[courseChoiceList.size()];
            for (int i = 0; i < courseChoiceList.size(); i++) {
                courseChoiceArray[i]= courseChoiceList.get(i);
            }
            courseChoice=new JComboBox(courseChoiceArray);
            courseChoice.setBounds(130,80,80,40);
            courseChoice.setSelectedIndex(1);
            courseChoice.addActionListener(this);
            enroll.addActionListener(this);
            panel.add(courseChoice);


        }catch (Exception ae){
            System.out.println(ae);
        }
        setContentPane(panel);
        setVisible(true);
//        return panel;
    }


    public void setCourseName(String courseName){
        this.courseName=courseName;
    }
    public String getCourseName(){
        return this.courseName;
    }

    public void setCourseId(String courseId){
        this.courseId=courseId;
    }
    String getCourseId(){
        return courseId;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
            try{
                Conn connection=new Conn();
                if(e.getSource()==courseChoice){
                    JComboBox jc=(JComboBox)e.getSource();
                    setCourseName((String)jc.getSelectedItem());
                    String sql="select * from courses;";
                    Statement st=connection.c.createStatement();
                    ResultSet rs= st.executeQuery(sql);
                    while(rs.next()){
                        if(rs.getString("courseName").equals(getCourseName())){
                            String sem_local=rs.getString("sem");
                            System.out.println(sem_local);
                            if(sem_local.equals("6")){
                                String [] semesterChoiceArray={"First","Second","Third","Forth","Fifth","Sixth"};
                                semesterChoice=new JComboBox(semesterChoiceArray);
                                semesterChoice.setBounds(340,80,120,40);
                                semesterChoice.setSelectedIndex(1);
                                semesterChoice.addActionListener(this);
                                panel.add(semesterChoice);
                                setVisible(true);

                            }

                            else if(sem_local.equals("8")){
                                semesterChoice=new JComboBox(new String[]{"First","Second","Third","Forth","Fifth","Sixth","Seventh,Last"});
                                semesterChoice.setBounds(270,80,120,40);
                                semesterChoice.setSelectedIndex(1);
                                semesterChoice.addActionListener(this);
                                panel.add(semesterChoice);
                            }
                        }

                    }

                    setVisible(true);

                }
                if(e.getSource()==semesterChoice){
                    JComboBox jb=(JComboBox)e.getSource();
                    String choice=(String) jb.getSelectedItem();
                    String sql="select * from courses";
                    Statement st=connection.c.createStatement();
                    ResultSet rs=st.executeQuery(sql);
                    while(rs.next()){
                        if(rs.getString("courseName").equals(getCourseName())){
                            optionalModules.clear();
                            optionalPanel.removeAll();
                            count=0;
                            String course_id=rs.getString("course_id");
                            System.out.println(course_id);
                            setCourseId(course_id);

                            //Once I got course_id I can search on module table having corresponding course_id for all modules that has same course_id

                            String sql1="select * from modules;";
                            Statement st1=connection.c.createStatement();
                            ResultSet rs1=st1.executeQuery(sql1);
                            while (rs1.next()){
                                if(choice=="First"){setSem("1");}
                                else if(choice=="Second"){setSem("2");}
                                else if(choice=="Third"){setSem("3");}
                                else if(choice=="Fourth"){setSem("4");}
                                else if(choice=="Fifth"){setSem("5");}
                                else if(choice=="Sixth"){setSem("6");}
                                else if(choice=="Seventh"){setSem("7");}
                                else if(choice=="Last"){setSem("8");}
                                if(course_id.equals(rs1.getString("course_id"))&&rs1.getString("semester").equals(getSem())){

                                        String moduleName=rs1.getString("moduleName");
                                        System.out.println(moduleName);
                                        if(rs1.getString("Choice").equals("Optional")){
                                            optionalModules.add(new JRadioButton(moduleName));
                                            setChoice("Optional");
                                            decide=true;
                                        }
//                                        else if(rs1.getString("Choice").equals("Compulsory")){
//                                            compulsoryModules.add(rs1.getString(moduleName));
//                                            count++;
//                                        }
                                    }

                            }
                            if(decide==false){
                                setChoice("Compulsory");
                                message=new JLabel("No Optional Modules");
                                message.setBounds(190,140,350,80);
                                message.setFont(new Font("Verdana",Font.PLAIN,18));
                                message.setForeground(Color.WHITE);
                                panel.add(message);
                                panel.setBackground(new Color(20,20,255));
                            }
                            else{
                                for(int i=0;i<optionalModules.size();i++){
                                    btnGrp1.add(optionalModules.get(i));
                                    optionalModules.get(i).addActionListener(this);
                                    optionalPanel.add(optionalModules.get(i));
                                }
                                optionalPanel.setLayout(new GridLayout(1,3));
                                optionalPanel.setBackground(new Color(200,20,255));
                                optionalPanel.setBounds(90,220,450,40);
                                message=new JLabel("Chose one of the module");
                                message.setBounds(190,140,350,80);
                                message.setFont(new Font("Verdana",Font.PLAIN,18));
                                message.setForeground(Color.WHITE);
                                panel.add(message);
                                panel.add(optionalPanel);
                                panel.setBackground(new Color(20,20,255));
                            }

                        }

                    }
                }
                if(e.getSource()==enroll){
                    System.out.println("courseId: "+ getCourseId()+" sem : "+getSem());

                    String sql="select * from modules where course_id=? and semester=?";
                    PreparedStatement ps=connection.c.prepareStatement(sql);
                    ps.setString(1,getCourseId());
                    ps.setString(2,getSem());

                    ResultSet rs=ps.executeQuery();
                    System.out.println(getValue());
                    int counting=0;
                    if(decide==false){
                        while (rs.next()){
                            String sql1="insert into student_enroll (student_id,moduleId) values(?,?);";
                            PreparedStatement ps1=connection.c.prepareStatement(sql1);
                            ps1.setString(1,getValue());
                            ps1.setString(2,rs.getString("moduleId"));
                            ps1.executeUpdate();

                        }
                    }
                    else{
                        while(rs.next()){
                            if(rs.getString("Choice").equals("Compulsory")){
                                String compModule=rs.getString("moduleId");
                                System.out.println(compModule);
                                String sql1="insert into student_enroll (student_id,moduleId) values(?,?);";
                                PreparedStatement ps1=connection.c.prepareStatement(sql1);
                                ps1.setString(1,getValue());
                                ps1.setString(2,compModule);
                                ps1.executeUpdate();

                            }
                            else{
                                counting++;
                            }

                        }
                    }
                    if(counting>0){
                        String opModule = null;
                        for (int i = 0; i < optionalModules.size(); i++) {
                            if(optionalModules.get(i).isSelected()){
                                opModule=optionalModules.get(i).getText();
                            }

                        }
                        PreparedStatement ps3=connection.c.prepareStatement("select * from modules where moduleName=?");
                        ps3.setString(1,opModule);
                        ResultSet rs3=ps3.executeQuery();
                        while(rs3.next()){
                            String sql1="insert into student_enroll (student_id,moduleId) values(?,?);";
                            PreparedStatement ps1=connection.c.prepareStatement(sql1);
                            ps1.setString(1,getValue());
                            ps1.setString(2,rs3.getString("moduleId"));
                            ps1.executeUpdate();

                        }
                        System.out.println(opModule);
                    }

                }
                setVisible(true);
            }catch (Exception ae){
                System.out.println(ae);
            }
    }


}
