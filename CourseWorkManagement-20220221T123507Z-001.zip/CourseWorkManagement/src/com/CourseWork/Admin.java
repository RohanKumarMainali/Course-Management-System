package com.CourseWork;

import javax.swing.*;
import java.awt.*;


public class Admin {
    public static void main(String[] args) {
        JFrame frame=new JFrame();
        JPanel panel=new JPanel();
        frame.setTitle("Course Management System");
        frame.setSize(420,420);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setVisible(true);
        ImageIcon image=new ImageIcon("C:/Users/user/Desktop/logo.png");       //Setting the icon
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(new Color(25,50,100));
        panel.setLayout(null);
        Label label=new Label();
        AdminHome obj5=new AdminHome();
    }
}
