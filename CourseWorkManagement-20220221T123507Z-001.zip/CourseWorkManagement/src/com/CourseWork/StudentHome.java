package com.CourseWork;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class StudentHome extends AdminHome {
    private JButton[] studentNav={new JButton("Home"),new JButton("Courses"),new JButton("Enroll"),new JButton("Logout")};

    private String studentIdGlobal;
    private JLabel text;
    private ArrayList<JButton> enrolledModule=new ArrayList<>();
    public void setStudentId(String studentId){
        this.studentIdGlobal=studentId;
    }
    public String getStudentId(){
        return studentIdGlobal;
    }

    public JPanel firstAdminFrame(){
        centrePanel = new JPanel();
        Conn connection=new Conn();
        boolean decide=true;
        try {
            PreparedStatement ps=connection.c.prepareStatement("select * from student_enroll where student_id=?");
            ps.setString(1,studentIdGlobal);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                String sql="select * from modules where moduleId=?";
                PreparedStatement ps1=connection.c.prepareStatement(sql);
                ps1.setString(1,rs.getString("moduleId"));
                ResultSet rs1=ps1.executeQuery();
                while(rs1.next()){
                    enrolledModule.add(new JButton(rs1.getString("moduleName")));
                }
                decide=false;
            }
            for (int i = 0; i < enrolledModule.size(); i++) {
                enrolledModule.get(i).setFont(new Font("Verdana", Font.PLAIN, 25));
                enrolledModule.get(i).setPreferredSize(new Dimension(400,200));
                enrolledModule.get(i).setBackground(new Color(20,100,100));
                enrolledModule.get(i).setBorder(new RoundedBorder(10));
                enrolledModule.get(i).setForeground(Color.white);
                centrePanel.add(enrolledModule.get(i));

            }
            centrePanel.setLayout(new FlowLayout(FlowLayout.CENTER,100,50));
            System.out.println("ID"+studentIdGlobal);
            if(decide==true){
                l2=new JLabel("You are not enrolled in any module");
                l2.setFont(new Font("Verdana", Font.PLAIN, 25));
                l2.setForeground(Color.WHITE);
                l2.setBounds(200,200,200,20);
                centrePanel.add(l2);
            }
        } catch (Exception ae) {
            System.out.println(ae);
        }

        ImageIcon img1=new ImageIcon("C:/Users/user/Desktop/instructor.png");
        Image img2=img1.getImage().getScaledInstance(200,200,Image.SCALE_DEFAULT);
        ImageIcon courseImg=new ImageIcon(img2);
        return centrePanel;

    }

    void studentHomeFrame(String studentId) throws SQLException {
        System.out.println(studentId);
        studentIdGlobal=studentId;
        StudentHome obj=new StudentHome();
        obj.setHeader("Student Dashboard");
        obj.setNavBar(studentNav);
        obj.setStudentId(studentId);
//        obj.centrePanel.removeAll();
        obj.adminHomeFrame();
    }

    public void actionPerformed(ActionEvent a) {
        try {
            Conn connection = new Conn();
            System.out.println("hello");
            if(a.getSource()==getNavBar()[0]){
                panel.removeAll();
                panel.add(upperBanner,BorderLayout.NORTH);
                panel.add(bottomPanel,BorderLayout.WEST);
                panel.add(centrePanel,BorderLayout.CENTER);
                setContentPane(panel);
//                System.out.println("clicked");
            }
                if (a.getSource() == getNavBar()[1]) {
                    panel.removeAll();
                    panel.add(upperBanner, BorderLayout.NORTH);
                    panel.add(bottomPanel, BorderLayout.WEST);
                    courseList.clear();
                    courseListPanel.removeAll();

                    String sql = "select * from courses";
                    Statement st = connection.c.createStatement();
                    ResultSet rs = st.executeQuery(sql);
                    while (rs.next()) {

                        String name = rs.getString("courseName");
                        String id = rs.getString("course_id");
                        String sem = rs.getString("sem");
                        courseList.add(new JButton(name + " \ncourse_id: " + id + " \n sem: " + sem));
                        courseIdList.add(id);


                    }
                    for (int i = 0; i < (courseList.size()); i++) {
                        courseListPanel.add((courseList.get(i))).setPreferredSize(new Dimension(200, 50));

                    }


                    courseListPanel.setPreferredSize(new Dimension(800, 200));

                    coursePanel1.add(coursePanelTitle, BorderLayout.NORTH);
                    coursePanel1.add(courseListPanel, BorderLayout.SOUTH);
                    coursePanel.add(coursePanel1);
                    panel.add(coursePanel, BorderLayout.CENTER);
                    setContentPane(panel);


                }
        } catch (Exception ae) {
            System.out.println(ae);
        }
        for (int i = 0; i < courseList.size(); i++) {
//
            courseList.get(i).addActionListener(this);
        }
        int key = 0;
        for (int i = 0; i < courseList.size(); i++) {
            if (a.getSource() == courseList.get(i)) {
                panel.remove(coursePanel);
                panel.remove(showModules);

//                panel.add();
                count = 1;
                key = i;
                break;
            }
            System.out.println("Check");

        }
        if (count == 1) {

            ShowModules obj = new ShowModules();
            showModules = obj.ShowModules(courseIdList.get(key));
            showModules.setBackground(new Color(0100, 50, 5));
            showModules.setPreferredSize(new Dimension(500, 500));
            panel.add(showModules);
            setContentPane(panel);
            setVisible(true);
        }
        if(a.getSource()==getNavBar()[2]){

            setContentPane(panel);
            System.out.println("check"+getStudentId());
            StudentEnroll obj=new StudentEnroll();
            obj.studentEnrollFrame(getStudentId());

        }
        if(a.getSource()==getNavBar()[3]){
            setVisible(false);
            new Login();
        }


    }

}
