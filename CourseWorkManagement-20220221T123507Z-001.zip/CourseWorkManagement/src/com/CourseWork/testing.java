package com.CourseWork;

public class testing {
    boolean check;
    int x=0;
    void check(){
        while(x<=2){
            if(x==5){
                check=false;
                System.out.println(check);
            }
            check=false;
            x++;
        }

    }


    public static void main(String[] args) {
        testing obj=new testing();
        obj.check();
    }
}
