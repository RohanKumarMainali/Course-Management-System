package com.CourseWork;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DeAllocateTeacher extends AssignTutor{
    void deAllocateTeacherFrame(){
        DeAllocateTeacher obj=new DeAllocateTeacher();
        obj.setAssign(new JButton("Deallocate"));
        obj.assignTutorFrame();

    }
    @Override
    public void actionPerformed(ActionEvent a) {
        try {
            Conn connection = new Conn();
            if(a.getSource()==getAssign()){
                System.out.println("check");
                String sql="select * from teacher";
                Statement st=connection.c.createStatement();
                ResultSet rs=st.executeQuery(sql);
                boolean decide=true;
                boolean decideNext=true;
                while (rs.next()){
                    if(rs.getString("name").equals(tutorNameText.getText())&& (rs.getString("id").equals(tutorIdText.getText()))){
                        System.out.println("Inside if");
                        decide=false;
                    }
                }
                if(decide==false){
                    String sql1="select * from modules";
                    Statement st1=connection.c.createStatement();
                    ResultSet rs1=st1.executeQuery(sql1);
                    while (rs1.next()){
                        if(rs1.getString("moduleId").equals(moduleIdText.getText())){
                            decideNext=false;

                        }
                    }
                }
                else{
                    JOptionPane.showMessageDialog(null,"Incorrect Teacher Name or ID");
                }
                if(decideNext==false){
                    String sql2="UPDATE `teacher` SET `moduleId` = NULL WHERE `teacher`.`id` = ? ;";
                    PreparedStatement ps=connection.c.prepareStatement(sql2);
                    ps.setString(1,tutorIdText.getText());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Teacher removed from this module");
                }
                else{
                    JOptionPane.showMessageDialog(null,"Incorrect Module ID");
                }
            }
        }
        catch (Exception ae){
            System.out.println(ae);

        }
    }

    public static void main(String[] args) {
        DeAllocateTeacher obj1=new DeAllocateTeacher();
        obj1.deAllocateTeacherFrame();
    }

}
