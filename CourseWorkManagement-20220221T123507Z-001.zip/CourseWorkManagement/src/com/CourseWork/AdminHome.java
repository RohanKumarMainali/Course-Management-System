package com.CourseWork;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.TreeSet;

public class AdminHome extends JFrame implements ActionListener {

        public static int count=0;
        public JPanel panel,upperBanner;
        public JPanel bodyPanel;
        public JPanel centrePanel,showModules,tutorPanel;
        public JPanel bottomPanel,coursePanel,courseListPanel,coursePanelTitle,coursePanel1,courseMethodPanel,studentPanel;
        public JButton btn1,btn2,btn3,btn4,btn5,btn6,home,back,courseButton,addCourse,removeCourse,addModule,removeModule,assignTutor,removeTutor;
        public JLabel l1,l2,l3,l4,l5,banner,courseAvailable;
        private ArrayList<JButton> navList=new ArrayList<>();

         public ArrayList <JButton> courseList=new ArrayList<>();
         public ArrayList<String> courseIdList=new ArrayList<>();

         private String header;
         private JButton[] navBar;

         public void setHeader(String header){
             this.header=header;
         }
         public String getHeader(){
             return this.header;
         }

         public void setNavBar(JButton [] navBar){
             this.navBar=navBar;
         }
         public JButton[] getNavBar(){
             return this.navBar;
         }

         public JPanel firstAdminFrame(){
             centrePanel = new JPanel();

             ImageIcon img1=new ImageIcon("C:/Users/user/Desktop/courses.png");
             Image img2=img1.getImage().getScaledInstance(200,200,Image.SCALE_DEFAULT);
             ImageIcon courseImg=new ImageIcon(img2);

             l2=new JLabel("",courseImg,JLabel.LEFT);
             l2.setHorizontalTextPosition(JLabel.LEFT);
             centrePanel.add(l2);
             return centrePanel;
         }

        void adminHomeFrame(){
            setTitle("Course Management System");
            setLayout(null);
            setSize(1650,1080);
            upperBanner = new JPanel();
            upperBanner.setBounds(0,0,1650,400);
            upperBanner.setPreferredSize(new Dimension(1650, 200));

            ImageIcon bannerImg=new ImageIcon("C:/Users/user/Desktop/book2.jpg");
            Image bannerImg1= bannerImg.getImage().getScaledInstance(1650,400,Image.SCALE_DEFAULT);
            ImageIcon bannerImgReal= new ImageIcon(bannerImg1);



            l1=new JLabel(getHeader());
            l1.setForeground(Color.white);
            l1.setFont(new Font("Roman", Font.BOLD, 40));
            l1.setVerticalTextPosition(JLabel.CENTER);
            l1.setHorizontalTextPosition(JLabel.LEFT);
            l1.setBounds(200,50,500,100);
            l1.setBackground(Color.black);

            banner=new JLabel(bannerImgReal);
            banner.add(l1);
            upperBanner.add(banner);

//
            ImageIcon image=new ImageIcon("C:/Users/user/Desktop/logo.png");
            setIconImage(image.getImage());
            setDefaultCloseOperation(EXIT_ON_CLOSE);

            panel=new JPanel();

            panel.setBackground(new Color(80,50,50));

            firstAdminFrame();

            addCourse=new JButton("Add Course");
            removeCourse=new JButton("Remove Course");
            addModule=new JButton("Add Module");
            removeModule=new JButton("Remove Module");
            assignTutor=new JButton("Assign Tutor");
            removeTutor=new JButton("Deallocate Tutor");
            assignTutor.addActionListener(this);
            removeTutor.addActionListener(this);


            courseMethodPanel=new JPanel();

            coursePanel=new JPanel();
            coursePanel.setBackground(new Color(0100,50,5));
            courseAvailable=new JLabel("Courses Available");
            courseAvailable.setFont(new Font("Roman", Font.BOLD, 30));
            courseAvailable.setForeground(Color.BLACK);
//            coursePanel.add(courseAvailable);

           coursePanelTitle=new JPanel();
           coursePanelTitle.setBackground(Color.WHITE);
           coursePanelTitle.add(courseAvailable);
           coursePanel.add(coursePanelTitle);

           coursePanel1=new JPanel();

            courseListPanel=new JPanel();
            courseListPanel.setBackground(new Color(100,50,200));

//
//            ImageIcon img3=new ImageIcon("C:/Users/user/Desktop/module.png");
//            Image img4=img3.getImage().getScaledInstance(200,170,Image.SCALE_DEFAULT);
//            ImageIcon moduleImg=new ImageIcon(img4);
//
//            l3=new JLabel("",moduleImg,JLabel.RIGHT);
//            l3.setHorizontalTextPosition(JLabel.LEFT);
//            centrePanel.add(l3);
//




            bottomPanel =new JPanel();



            int length=getNavBar().length;
            for(int i=0;i<length;i++){
                getNavBar()[i].setBackground(new Color(20,100,100));
                getNavBar()[i].setForeground(Color.WHITE);
                navList.add(getNavBar()[i]);
            }
            for(int i=0;i<length;i++){
                bottomPanel.add(getNavBar()[i]);
                getNavBar()[i].addActionListener(this);
            }

            System.out.println(length);


            back=new JButton("Back");
            bottomPanel.setBackground(new Color(0100,50,5));
            bottomPanel.setLayout(new GridLayout(12,1));
            bottomPanel.setPreferredSize(new Dimension(200,50));

            centrePanel.setBackground(new Color(0100,50,5));

            add(panel,BorderLayout.PAGE_START);
            addCourse.addActionListener(this);
            removeCourse.addActionListener(this);


//            add(bottomPanel);
            panel.setLayout(new BorderLayout());
            panel.add(upperBanner,BorderLayout.NORTH);
            panel.add(bottomPanel,BorderLayout.WEST);
            panel.add(centrePanel,BorderLayout.CENTER);

            showModules=new JPanel();
            tutorPanel=new JPanel();
            studentPanel=new JPanel();
            addModule.addActionListener(this);
            removeModule.addActionListener(this);

            setContentPane(panel);
            setVisible(true);

        }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            Conn connection = new Conn();
            System.out.println(getNavBar()[1]);

            if (e.getSource() == getNavBar()[1]) {
                panel.removeAll();
                panel.add(upperBanner,BorderLayout.NORTH);
                panel.add(bottomPanel,BorderLayout.WEST);
                courseList.clear();
                courseListPanel.removeAll();
                courseMethodPanel.removeAll();
                String sql = "select * from courses";
                Statement st = connection.c.createStatement();
                ResultSet rs = st.executeQuery(sql);
                courseIdList.clear();
                while (rs.next()) {

                    String name = rs.getString("courseName");
                    String id = rs.getString("course_id");
                    String sem = rs.getString("sem");
                    courseList.add(new JButton(name + " \ncourse_id: " + id + " \n sem: " + sem));
                    courseIdList.add(id);


                }
                for (int i = 0; i < (courseList.size()); i++) {
                    courseListPanel.add((courseList.get(i))).setPreferredSize(new Dimension(200, 50));

                }


                courseListPanel.setPreferredSize(new Dimension(800, 200));
                courseMethodPanel.add(addCourse);
                courseMethodPanel.add(removeCourse);
                courseMethodPanel.add(addModule);
                courseMethodPanel.add(removeModule);
                courseMethodPanel.add(assignTutor);
                courseMethodPanel.add(removeTutor);
                if(getNavBar().length==4){
                    courseMethodPanel.removeAll();
                }
                courseMethodPanel.setLayout(new GridLayout(3, 2));

                courseListPanel.add(courseMethodPanel, BorderLayout.EAST);
//                    courseListPanel.setLayout(new );
                coursePanel1.add(coursePanelTitle, BorderLayout.NORTH);
                coursePanel1.add(courseListPanel, BorderLayout.SOUTH);

//                    coursePanel1.setLayout(new GridLayout(2,1));
                coursePanel.add(coursePanel1);
                panel.add(coursePanel, BorderLayout.CENTER);
                setContentPane(panel);



            }

        } catch (Exception ae) {
            System.out.println(ae);
        }
        for (int i = 0; i < courseList.size(); i++) {
//
            courseList.get(i).addActionListener(this);
        }
        int key = 0;
        for (int i = 0; i < courseList.size(); i++) {
            if (e.getSource() == courseList.get(i)) {
                panel.remove(coursePanel);
                panel.remove(showModules);

//                panel.add();
                count = 1;
                key = i;
                break;
            }
            System.out.println("Check");

        }
        if (count == 1) {

            ShowModules obj= new ShowModules();
//            System.out.println(courseIdList.get(3));
            showModules=obj.ShowModules(courseIdList.get(key));
            showModules.setBackground(new Color(0100,50,5));
            showModules.setPreferredSize(new Dimension(500,500));
            panel.add(showModules);
            setContentPane(panel);
            setVisible(true);
        }



        if (e.getSource() == addCourse) {
            AddCourse obj = new AddCourse();
            obj.setAddBtn(new JButton("Add"));
            obj.addCourseFrame();
        }
        if (e.getSource() == removeCourse) {
            RemoveCourse obj1 = new RemoveCourse();
            obj1.remove();
        }
        if(e.getSource()==addModule){
            AddModule obj= new AddModule();
            obj.setAddBtn(new JButton("Add"));
            obj.addModuleFrame();
        }
        if(e.getSource()==removeModule){
            RemoveModule obj=new RemoveModule();
            obj.remove();
        }
        if(e.getSource()==assignTutor){
            AssignTutor obj=new AssignTutor();
            obj.setAssign(new JButton("Assign"));
            obj.assignTutorFrame();
        }
        if(e.getSource()==removeTutor){
            DeAllocateTeacher obj1=new DeAllocateTeacher();
            obj1.deAllocateTeacherFrame();
        }
        if (e.getSource() == getNavBar()[0]) {
            panel.remove(coursePanel);
            panel.remove(tutorPanel);
            panel.remove(showModules);
            panel.remove(tutorPanel);
            panel.add(centrePanel);
            setContentPane(panel);
            setVisible(true);


        }

        if (e.getSource() == getNavBar()[2]) {
           panel.removeAll();
            panel.add(upperBanner,BorderLayout.NORTH);
            panel.add(bottomPanel,BorderLayout.WEST);

            ShowTutor obj=new ShowTutor();
            tutorPanel=obj.ShowTutor();
            panel.add(tutorPanel);
            setContentPane(panel);
            setVisible(true);


        }
        if (e.getSource() == getNavBar()[3]) {
            setVisible(false);
            new AdminResult();
        }

        if(e.getSource()==getNavBar()[4]){
            panel.removeAll();
            panel.add(upperBanner,BorderLayout.NORTH);
            panel.add(bottomPanel,BorderLayout.WEST);
            Student obj=new Student();
            studentPanel=obj.ShowStudent();
            panel.add(studentPanel);
            setContentPane(panel);
            setVisible(true);
        }


    }
    void Display(String course_id){


    }




    public static void main(String[] args) {
           AdminHome obj= new AdminHome();
           obj.adminHomeFrame();


    }
}
