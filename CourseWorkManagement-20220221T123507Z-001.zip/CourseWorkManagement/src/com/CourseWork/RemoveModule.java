package com.CourseWork;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class RemoveModule extends AddModule{

    void remove(){
        RemoveModule obj=new RemoveModule();
        obj.setAddBtn(new JButton("Remove"));
        obj.addModuleFrame();

    }

    @Override
    public void actionPerformed(ActionEvent a) {
        try {
            Conn connection = new Conn();

            if(a.getSource()==add){
                if(courseNameText.getText().equals("")){
                    JOptionPane.showMessageDialog(null,"Please Enter Course Name");
                }
                else{
                    String sql1="select * from courses";
                    String sql2="select * from modules";
                    Statement st=connection.c.createStatement();
                    ResultSet rs=st.executeQuery(sql1);
                    Statement st1=connection.c.createStatement();
                    ResultSet rs1=st1.executeQuery(sql2);
                    boolean decide = true;

                    while(rs.next()) {
                        if (rs.getString("courseName").equals(courseNameText.getText()) && (rs.getString("course_id").equals(courseIdText.getText()))) {
                            decide=false;
                        }
                    }
                    while(rs1.next()){
                        if(decide==true){
                            JOptionPane.showMessageDialog(null,"Incorrect courseName or courseId");
                        }
                        else if(rs1.getString("moduleId").equals(moduleIdText.getText())){
                            String sql="delete from modules where moduleId=?;";
                            PreparedStatement ps=connection.c.prepareStatement(sql);
                            ps.setString(1,moduleIdText.getText());
                            ps.executeUpdate();
                            JOptionPane.showMessageDialog(null,"Module Deleted Successfully");
                        }
                    }

                }

            }
        }catch (Exception ae){
            System.out.println(ae);
        }
        }

    public static void main(String[] args) {
        RemoveModule obj1=new RemoveModule();
        obj1.remove();
    }



}
