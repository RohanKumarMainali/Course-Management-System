package com.CourseWork;

import javax.swing.*;
import javax.xml.transform.Result;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class AddTutor extends JFrame implements ActionListener {
    private JPanel panel;
    private JLabel tutorName,id,age,gender,phoneNumber,address;
    private JTextField tutorNameText,idText,ageText,phoneNumberText,addressText;
    private JRadioButton genderText1,genderText2;
    private JButton add;
    private ButtonGroup btnGroup;


    void addTutorFrame(){
        setLayout(null);

        setBounds(400,150,600,380);
        add=new JButton("Add");
        panel=new JPanel();
        panel.setLayout(null);

        tutorName=new JLabel("Name: ");
        tutorName.setFont(new Font("Verdana", Font.PLAIN, 18));
        tutorName.setBounds(40,40,200,40);
        panel.add(tutorName);

        tutorNameText=new JTextField();
        tutorNameText.setBounds(250,40,300,35);
        panel.add(tutorNameText);

        id=new JLabel("Teacher ID:");
        id.setFont(new Font("Verdana", Font.PLAIN, 18));
        id.setBounds(40,80,200,40);
        panel.add(id);

        idText=new JTextField();
        idText.setBounds(250,80,300,35);
        panel.add(idText);

        age=new JLabel("Age:");
        age.setFont(new Font("Verdana", Font.PLAIN, 18));
        age.setBounds(40,120,200,40);
        panel.add(age);

        ageText=new JTextField();
        ageText.setBounds(250,120,300,35);
        panel.add(ageText);

        gender=new JLabel("Gender:");
        gender.setFont(new Font("Verdana", Font.PLAIN, 18));
        gender.setBounds(40,160,200,40);
        panel.add(gender);

        genderText1=new JRadioButton("Male");
        genderText1.setBounds(250,160,90,35);
        genderText1.setActionCommand("Male");

        genderText2=new JRadioButton("Female");
        genderText2.setBounds(350,160,150,35);
        genderText2.setActionCommand("Female");

        btnGroup=new ButtonGroup();
        btnGroup.add(genderText1);
        btnGroup.add(genderText2);

        genderText1.addActionListener(this);
        genderText2.addActionListener(this);
        panel.add(genderText1);
        panel.add(genderText2);


        phoneNumber=new JLabel("Phone No:");
        phoneNumber.setFont(new Font("Verdana", Font.PLAIN, 18));
        phoneNumber.setBounds(40,200,200,40);
        panel.add(phoneNumber);

        phoneNumberText=new JTextField();
        phoneNumberText.setBounds(250,200,300,35);
        panel.add(phoneNumberText);

        address=new JLabel("Address:");
        address.setFont(new Font("Verdana", Font.PLAIN, 18));
        address.setBounds(40,240,200,40);
        panel.add(address);

        addressText=new JTextField();
        addressText.setBounds(250,240,300,35);
        panel.add(addressText);

        add.setBounds(225,290,100,35);
        add.addActionListener(this);
        panel.add(add);

        setContentPane(panel);
        setVisible(true);



    }
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
//            RemoveCourse obj=new RemoveCourse();
            Conn connection =new Conn();
            if(e.getSource()==add){
                String sql="select * from teacher;";
                Statement st= connection.c.createStatement();
                ResultSet rs=st.executeQuery(sql);
                boolean decide=true;
                while(rs.next()){
                    if(rs.getString("id").equals(tutorNameText.getText())){
                        JOptionPane.showMessageDialog(null,"Cannot add duplicate id");
                        decide=false;
                    }

                }
                if(decide==true){
                    String sql1="insert into teacher (name,id,age,gender,phoneNumber,address) values (?,?,?,?,?,?);";
                    PreparedStatement ps=connection.c.prepareStatement(sql1);
                    ps.setString(1,tutorNameText.getText());
                    ps.setString(2,idText.getText());
                    ps.setString(3,ageText.getText());
                    ps.setString(4, String.valueOf(btnGroup.getSelection().getActionCommand()));
                    System.out.println(btnGroup.getSelection().getActionCommand());
                    ps.setString(5,phoneNumberText.getText());
                    ps.setString(6,addressText.getText());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Teacher added successfully");

                }
            }
        }catch (Exception ae){
            System.out.println(ae);
        }

    }

    public static void main(String[] args) {
        AddTutor obj=new AddTutor();
        obj.addTutorFrame();
    }
}
