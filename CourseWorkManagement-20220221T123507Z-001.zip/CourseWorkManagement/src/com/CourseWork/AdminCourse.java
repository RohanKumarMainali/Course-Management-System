package com.CourseWork;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class AdminCourse extends JFrame implements ActionListener {
    private JButton btn1,btn2,btn3,btn4,btn5,btn6,btn7,viewCourse;
    private JLabel courseName;
    private JLabel course1,course2,course3,moduleName,tutorName;

    private JTextField courseText,moduleText,tutorText;
    private JPanel bodyPanel,upperPanel,lowerPanel;

    AdminCourse(){

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setBounds(400,100,900,500);
        upperPanel = new JPanel();

        courseName = new JLabel("Course Name: ");
        courseName.setBounds(50,30,250,25);
        upperPanel.add(courseName);

        courseText =new JTextField();
        courseText.setBounds(150,30,200,25);
        upperPanel.setLayout(null);
        upperPanel.add(courseText);

        moduleName=new JLabel("Module Name:");
        moduleName.setBounds(50,60,250,25);
        upperPanel.add(moduleName);

        moduleText=new JTextField();
        moduleText.setBounds(150,60,200,25);
        upperPanel.add(moduleText);

        tutorName = new JLabel("Tutor Name:");
        tutorName.setBounds(50,90,200,25);
        upperPanel.add(tutorName);

        tutorText=new JTextField();
        tutorText.setBounds(150,90,200,25);
        upperPanel.add(tutorText);

        btn1 = new JButton("Add Course");
        btn1.setBounds(400,30,100,25);
        btn1.setForeground(Color.black);
        btn1.setBackground(Color.white);
        upperPanel.add(btn1);

        btn2 = new JButton("Remove Course");
        btn2.setBounds(600,30,150,25);
        btn2.setForeground(Color.black);
        btn2.setBackground(Color.white);
        upperPanel.add(btn2);

        btn3=new JButton("View available courses");
        btn3.setBounds(300,150,250,25);
        btn3.setForeground(Color.black);
        btn3.setBackground(Color.white);
        upperPanel.add(btn3);
        btn3.addActionListener(this);

        btn4=new JButton("Add Module");
        btn4.setBounds(400,60,150,25);
        btn4.setForeground(Color.black);
        btn4.setBackground(Color.white);
        upperPanel.add(btn4);
        btn4.addActionListener(this);


        btn5=new JButton("Remove Module");
        btn5.setForeground(Color.black);
        btn5.setBackground(Color.white);
        btn5.setBounds(600,60,150,25);
        upperPanel.add(btn5);

        btn6=new JButton("Add Tutor");
        btn6.setBounds(400,90,150,25);
        btn6.setForeground(Color.black);
        btn6.setBackground(Color.white);
        upperPanel.add(btn6);
        btn6.addActionListener(this);

        btn7=new JButton("Remove Tutor");
        btn7.setBounds(600,90,150,25);
        btn7.setForeground(Color.black);
        btn7.setBackground(Color.white);
        upperPanel.add(btn7);

        lowerPanel = new JPanel();
        TitledBorder title;
        title=BorderFactory.createTitledBorder("Courses Available ");
        lowerPanel.setBorder(title);



        bodyPanel=new JPanel();
        bodyPanel.add(upperPanel);
        bodyPanel.add(lowerPanel);
        bodyPanel.setForeground(Color.black);
        bodyPanel.setBounds(20,20,500,500);

        bodyPanel.setLayout(new GridLayout(2,1));

        setContentPane(bodyPanel);
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn5.addActionListener(this);
//        btn6.addActionListener(this);
        btn7.addActionListener(this);


        setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        try{
            Conn connection = new Conn();
            if(e.getSource()==btn1){
                String sql1="select * from course";
                Statement st=connection.c.createStatement();
                ResultSet rs=st.executeQuery(sql1);
                boolean decide=true;
                while(rs.next()){
                    if(rs.getString("courseName").equals(courseText.getText())){

                        decide=false;
                    }
                }
                if(decide==true){
                    String sql="insert into course (courseName) values(?)";
                    PreparedStatement ps=connection.c.prepareStatement(sql);
                    String name=courseText.getText();
                    ps.setString(1,name);
                    ps.executeUpdate();
                    courseText.setText("");
                }
                else{
                    JOptionPane.showMessageDialog(null,"Cannot add duplicate course");
                }

            }
            if(e.getSource()==btn2){
                String sql="delete from course where courseName=?";
                String name=courseText.getText();
                PreparedStatement ps=connection.c.prepareStatement(sql);
                ps.setString(1,name);
                ps.executeUpdate();
                courseText.setText("");

            }
            if(e.getSource()==btn4){                // Code for add module
                if(courseText.getText().equals("")){
                    JOptionPane.showMessageDialog(null,"Please enter the course name");
                }
                else{
                        String sql1="select * from course";
                        Statement st=connection.c.createStatement();
                        ResultSet rs=st.executeQuery(sql1);
                        boolean decide=true;

                        while(rs.next()){
                            if(rs.getString("courseName").equals(courseText.getText())){
                                decide=false;
                            }

                        }
                        if(decide==true){
                            JOptionPane.showMessageDialog(null,"Please enter correct Course Name");
                        }
                        else{
                            String sql="insert into course (courseName,moduleName) values (?,?);";
                            PreparedStatement ps=connection.c.prepareStatement(sql);
                            ps.setString(1,courseText.getText());
                            ps.setString(2,moduleText.getText());
                            ps.executeUpdate();
                            JOptionPane.showMessageDialog(null,"Module added successfully");
                        }
                }
                //Below code remove module
            }
            if(e.getSource()==btn5){
                System.out.println(moduleText.getText());
                String sql1="select * from course";
                Statement st=connection.c.createStatement();
                ResultSet rs=st.executeQuery(sql1);
                boolean decide=true;
                while(rs.next()) {
                    if (moduleText.getText().equals("")) {
                        JOptionPane.showMessageDialog(null, "Please enter the course name");
                    } else {
                        if (rs.getString("moduleName").equals(moduleText.getText())) {
                            String sql = "delete from course where moduleName=?";
                            PreparedStatement ps = connection.c.prepareStatement(sql);
                            ps.setString(1, moduleText.getText());
                            ps.executeUpdate();
                            decide = false;
                            System.out.println("check");
                        }

                        }
                }
                    if (decide == true){
                        JOptionPane.showMessageDialog(null, "Please enter correct module name");
                    }
                    else{
                        JOptionPane.showMessageDialog(null,"module removed successfully");
                    }



            } //Code for add tutor
            if(e.getSource()==btn6){
                if(courseText.getText().equals("") || tutorText.getText().equals("")){
                    JOptionPane.showMessageDialog(null,"Please enter both course name and module name");
                }
                else{
                    try{
                        String sql1="select * from course";
                        Statement st=connection.c.createStatement();
                        ResultSet rs=st.executeQuery(sql1);
                        boolean decide=true;
                        while(rs.next()){
                            if(rs.getString("moduleName").equals(moduleText.getText()) && rs.getString("courseName").equals
                                    (courseText.getText())){

                                decide=false;
                            }
                        }
                        if(decide==true){
                            JOptionPane.showMessageDialog(null,"Enter correct module name and course name");
                        }
                        else{
                            String sql="insert into course (courseName,moduleName,tutorName) values (?,?,?);";
                            PreparedStatement ps=connection.c.prepareStatement(sql);
                            ps.setString(1,courseText.getText());
                            ps.setString(2,moduleText.getText());
                            ps.setString(3,tutorText.getText());
                            ps.executeUpdate();
                            JOptionPane.showMessageDialog(null,"Tutor assigned successfully");
                        }
                        courseText.setText("");
                        moduleText.setText("");
                        tutorText.setText("");
                    }catch (Exception ex){
                        System.out.println(ex);
                    }
                }
            }
            //code for remove tutor
            if(e.getSource()==btn7){
                try{
                    String sql="delete from course where tutorName =?";
                    PreparedStatement ps=connection.c.prepareStatement(sql);
                    ps.setString(1,tutorText.getText());
                    ps.executeUpdate();
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,"Enter correct tutor name");

                }

            }
            //Below code is for view all availabel course
            if(e.getSource()==btn3){
                lowerPanel.removeAll();

                setContentPane(bodyPanel);
                String sql="select distinct courseName from course";
                Statement st=connection.c.createStatement();
                ResultSet rs = st.executeQuery(sql);
                while(rs.next()){

                    String name=rs.getString("courseName");
                    viewCourse=new JButton(name);
                    viewCourse.setBounds(5,2,100,20);
                    lowerPanel.add(viewCourse);
                    lowerPanel.setLayout(new FlowLayout(FlowLayout.LEFT));


//                    lowerPanel.setLayout(new GridLayout(10,1));

                    setContentPane(bodyPanel);
                    setVisible(true);

                    System.out.println(name);
                }


            }
        }catch (Exception ex){
            System.out.println(ex);
        }
        viewCourse.addActionListener(this);
        if(e.getSource()==viewCourse){
            System.out.println("check");
        }

    }

    public static void main(String[] args) {
        new AdminCourse();

    }
}
