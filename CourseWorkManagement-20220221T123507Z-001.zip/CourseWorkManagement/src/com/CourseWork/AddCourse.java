package com.CourseWork;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class AddCourse extends JFrame implements ActionListener {
    public JTextField t1,t2,t3;
    public JLabel l1,l2,l3;
    public JButton addBtn;
    public JPanel panel,leftDetails,rightDetails,addButton;




     void addCourseFrame(){
        setLayout(null);
        setBounds(600,250,400,250);
        l1 =new JLabel("Course Name: ");
        l2 =new JLabel("Course Id: ");
        l3 =new JLabel("Semester: ");
        l1.setFont(new Font("Roman", Font.BOLD, 15));
        l1.setBounds(20,20,40,40);
        l2.setFont(new Font("Roman", Font.BOLD, 15));
        l3.setFont(new Font("Roman", Font.BOLD, 15));

         addBtn=getAddBtn();
        t1=new JTextField();
        t2=new JTextField();
        t3=new JTextField();
        leftDetails=new JPanel();
        rightDetails=new JPanel();
        leftDetails.add(l1);
        leftDetails.add(l2);
        leftDetails.add(l3);
        rightDetails.add(t1);
        rightDetails.add(t2);
        rightDetails.add(t3);
        rightDetails.setPreferredSize(new Dimension(250,50));
        leftDetails.setLayout(new GridLayout(3,1));
        rightDetails.setLayout(new GridLayout(3,1));
        panel=new JPanel();


        panel.add(leftDetails);
        panel.add(rightDetails);
        panel.add(addBtn);
        setContentPane(panel);
        setVisible(true);
        addBtn.addActionListener(this);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try{
            Conn connection = new Conn();
            if(e.getSource()==addBtn){
                String sql1="select * from courses";
                Statement st=connection.c.createStatement();
                ResultSet rs=st.executeQuery(sql1);
                boolean decide=true;
                while(rs.next()){
                    if(rs.getString("courseName").equals(t1.getText())){

                        decide=false;
                    }
                }
                if(decide==true){
                    System.out.println("check");
                    String sql="insert into courses (courseName,course_id,sem) values(?,?,?)";
                    PreparedStatement ps=connection.c.prepareStatement(sql);
                    String name=t1.getText();
                    String id=t2.getText();
                    String sem=t3.getText();
                    ps.setString(1,name);
                    ps.setString(2,id);
                    ps.setString(3,sem);
                    ps.executeUpdate();
                }
                else{
                    JOptionPane.showMessageDialog(null,"Cannot add duplicate course");
                }

            }
        }catch (Exception ae){
            System.out.println(ae);
        }



    }
    void setAddBtn(JButton addBtn){
        this.addBtn=addBtn;
    }
    JButton getAddBtn(){
         return addBtn;
    }

    public static void main(String[] args) {
        AddCourse obj=new AddCourse();
        obj.setAddBtn(new JButton("Add"));
        obj.addCourseFrame();
    }
}
