package com.CourseWork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.image.AreaAveragingScaleFilter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TutorHome extends AdminHome{
    private JButton[] tutorNav={new JButton("Home"),new JButton("Students"),new JButton("Mark Students"),new JButton("Logout")};

    public String tutorIdGlobal;
    private String moduleId,moduleName;
    private ArrayList<String> studentList=new ArrayList<>();
    private ArrayList<JTextField> studentTextField=new ArrayList<JTextField>();
    private ArrayList<JButton> submit=new ArrayList<>();
    private JTable table;
    private JTextField t1=new JTextField();
    private String [] columnName={"Student Name","Marks Obtained","Submit"};
    private int count=0;

    public void setTutorId(String tutorId){
        tutorIdGlobal=tutorId;
    }
    public String getTutorId(){
        return tutorIdGlobal;
    }


    void tutorHomeFrame(String tutorId){
        System.out.println(tutorId);
        tutorIdGlobal=tutorId;
        System.out.println("checking: "+tutorIdGlobal);
        TutorHome obj=new TutorHome();
        obj.setTutorId(tutorId);
        obj.setNavBar(tutorNav);
        obj.setHeader("Tutor Dashboard");
        obj.adminHomeFrame();
    }
    public JPanel firstAdminFrame(){
        centrePanel = new JPanel();
        Conn connection=new Conn();
        boolean decide=true;
        try{
            PreparedStatement ps=connection.c.prepareStatement("select moduleId from teacher where id=?"); //to get the courseId on which teacher is assigned
            ps.setString(1,getTutorId());
            ResultSet rs=ps.executeQuery();
            while (rs.next()){
                moduleId=rs.getString("moduleId");
            }
            if(moduleId==null){
                JLabel message=new JLabel("You are not assigned in any module");
                message.setFont(new Font("Verdana", Font.PLAIN, 25));
                message.setForeground(Color.WHITE);
                message.setBounds(200,200,200,20);
                centrePanel.add(message);
            }
            else{
                System.out.println(moduleId);// I got moduleId so now I should search moduleName of that module Id and display it on home frame of teacher
                PreparedStatement ps1=connection.c.prepareStatement("select moduleName from modules where moduleId=?");
                ps1.setString(1,moduleId);
                ResultSet rs1=ps1.executeQuery();
                while (rs1.next()){
                    moduleName=rs1.getString("moduleName");
                    JButton moduleNameBtn=new JButton(moduleName);
                    moduleNameBtn.setPreferredSize(new Dimension(400,200));
                    moduleNameBtn.setFont(new Font("Verdana", Font.PLAIN, 25));
                    moduleNameBtn.setBackground(new Color(20,100,100));
                    moduleNameBtn.setBorder(new RoundedBorder(10));
                    moduleNameBtn.setForeground(Color.white);
                    moduleNameBtn.setFocusPainted(true);
                    moduleNameBtn.setBorderPainted(true);
                    moduleNameBtn.setContentAreaFilled(true);
                    centrePanel.add(moduleNameBtn);

                }
                centrePanel.setLayout(new FlowLayout(FlowLayout.CENTER,100,50));
                System.out.println(moduleName);
            }

        }catch (Exception e){
            System.out.println(e);
        }
        System.out.println("check"+getTutorId());
        return centrePanel;

    }

    public void actionPerformed(ActionEvent a) {
        Conn connection =new Conn();
        if(a.getSource()==getNavBar()[0]){
            panel.removeAll();
            panel.add(upperBanner,BorderLayout.NORTH);
            panel.add(bottomPanel,BorderLayout.WEST);
            panel.add(centrePanel,BorderLayout.CENTER);
            setContentPane(panel);
        }
        if(a.getSource()==getNavBar()[1]){
            System.out.println("button check");
            panel.removeAll();
            panel.add(upperBanner,BorderLayout.NORTH);
            panel.add(bottomPanel,BorderLayout.WEST);
            JPanel studentPanel=new JPanel();
            studentPanel.setLayout(null);
            JLabel fullMark=new JLabel("Full Mark");
            fullMark.setFont(new Font("Verdana", Font.PLAIN, 25));
            fullMark.setForeground(Color.white);
            fullMark.setBounds(400,20,170,30);
            studentPanel.add(fullMark);
            studentPanel.setBackground(new Color(0100,50,5));
            JTextField fullMarkText=new JTextField();
            fullMarkText.setBounds(580,20,100,30);
            studentPanel.add(fullMarkText);
            JButton setFullMark=new JButton("Set");
            setFullMark.setBounds(700,20,80,30);
            setFullMark.setForeground(Color.WHITE);
            setFullMark.setBackground(new Color(20,100,100));
            setFullMark.addActionListener(this);
            studentPanel.add(setFullMark);



            try{
                PreparedStatement ps=connection.c.prepareStatement("select student_id from student_enroll where moduleId=?");
                ps.setString(1,moduleId);
                ResultSet rs=ps.executeQuery();
                while (rs.next()){

                    String studentId=rs.getString("student_id");  // getting student id
                    System.out.println(studentId);
                    PreparedStatement ps1=connection.c.prepareStatement("select * from student_details where student_id=?");
                    ps1.setString(1,studentId);   // Now getting studentName from student_details table using student Id
                    ResultSet rs1=ps1.executeQuery();
                    while(rs1.next()){
                        System.out.println("loop check");
                        studentList.add(rs1.getString("student_name"));
                        studentTextField.add(new JTextField());
                        submit.add(new JButton("submit"));

                    }
                    count++;


                    for (int i = 0; i < studentList.size(); i++) {
                        System.out.println("Check  for loop"+studentList.get(i));
                    }
                }
                JPanel displayStudent=new JPanel();

                displayStudent.setLayout(null);
                for (int i = 0; i < count; i++) {
                    displayStudent.add(new JLabel(studentList.get(i)));
                    studentTextField.get(i).setPreferredSize(new Dimension(100,20));
                    displayStudent.add(studentTextField.get(i));
                    displayStudent.add(submit.get(i));
                }
                displayStudent.setBounds(300,100,650,400);
                displayStudent.setLayout(new FlowLayout(FlowLayout.CENTER));
                displayStudent.setBackground(Color.WHITE);
                studentPanel.add(displayStudent);
                panel.add(studentPanel,BorderLayout.CENTER);
                setContentPane(panel);
            }catch (Exception e){
                System.out.println(e);
            }

        }
    }

}
