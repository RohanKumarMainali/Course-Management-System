package com.CourseWork;

import javax.swing.*;
import javax.xml.transform.Result;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class AssignTutor extends JFrame implements ActionListener {
    private JPanel panel;
    private JButton assign;
    public JLabel tutorName,tutorId,moduleId;
    public JTextField tutorNameText,tutorIdText,moduleIdText;

    public void setAssign(JButton assign){
        this.assign=assign;
    }
    JButton getAssign(){
        return assign;
    }

    public void assignTutorFrame(){
        panel=new JPanel();
        panel.setLayout(null);
        setBounds(400,150,600,380);
        tutorName=new JLabel("Name: ");
        tutorName.setFont(new Font("Verdana", Font.PLAIN, 18));
        tutorName.setBounds(40,40,200,40);
        panel.add(tutorName);

        tutorNameText=new JTextField();
        tutorNameText.setBounds(250,40,300,35);
        panel.add(tutorNameText);

        tutorId=new JLabel("Teacher ID:");
        tutorId.setFont(new Font("Verdana", Font.PLAIN, 18));
        tutorId.setBounds(40,80,200,40);
        panel.add(tutorId);

        tutorIdText=new JTextField();
        tutorIdText.setBounds(250,80,300,35);
        panel.add(tutorIdText);

        moduleId=new JLabel("Module ID: ");
        moduleId.setFont(new Font("Verdana", Font.PLAIN, 18));
        moduleId.setBounds(40,120,200,40);
        panel.add(moduleId);

        moduleIdText=new JTextField();
        moduleIdText.setBounds(250,120,300,35);
        panel.add(moduleIdText);

        getAssign().setBounds(230,200,100,35);
        getAssign().addActionListener(this);
        panel.add(getAssign());


        setContentPane(panel);
        setVisible(true);

    }


    @Override
    public void actionPerformed(ActionEvent e) {
       try{
           Conn connection = new Conn();
           if(e.getSource()==getAssign()){
               String sql="select * from teacher";
               Statement st=connection.c.createStatement();
               ResultSet rs=st.executeQuery(sql);
               boolean decide=true;
               boolean decideNext=true;
               while (rs.next()){
                   if(rs.getString("name").equals(tutorNameText.getText())&& (rs.getString("id").equals(tutorIdText.getText()))){
                       System.out.println("Inside if");
                       decide=false;
                   }
               }
               if(decide==false){
                   String sql1="select * from modules";
                   Statement st1=connection.c.createStatement();
                   ResultSet rs1=st1.executeQuery(sql1);
                   while (rs1.next()){
                       if(rs1.getString("moduleId").equals(moduleIdText.getText())){
                           decideNext=false;

                       }
                   }
               }
               else{
                   JOptionPane.showMessageDialog(null,"Incorrect Teacher Name or ID");
               }
               if(decideNext==false){
                   String sql2="UPDATE `teacher` SET `moduleId` = ? WHERE `teacher`.`id` = ? ;";
                   PreparedStatement ps=connection.c.prepareStatement(sql2);
                   ps.setString(1,moduleIdText.getText());
                   ps.setString(2,tutorIdText.getText());
                   ps.executeUpdate();
                   JOptionPane.showMessageDialog(null,"Teacher Assigned");
               }
               else{
                   JOptionPane.showMessageDialog(null,"Incorrect Module ID");
               }
           }
       }catch (Exception ae){
           System.out.println(ae);
       }

    }

    public static void main(String[] args) {
        AssignTutor obj=new AssignTutor();
        obj.setAssign(new JButton("Assign"));
        obj.assignTutorFrame();
    }
}
