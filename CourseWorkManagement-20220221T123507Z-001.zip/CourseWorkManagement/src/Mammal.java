public class Mammal implements Reptile {
    public static void main(String[] args) {
        Mammal obj=new Mammal();
        Reptile obj1=new Mammal();
        obj.move();
        obj.sleep();
    }

    @Override
    public void move() {
        System.out.println("I am moving");
    }
    public void sleep(){
        System.out.println("I am sleeping child");
    }


}
